# 💰 SalvaMoney Bot — WhatsApp

Bot em Node.js que recebe mensagens do WhatsApp pela Z-API, interpreta gastos e salva no Firebase Realtime Database no formato usado pelo SalvaMoney.

## O que este bot faz

- Recebe webhook da Z-API em `/webhook`
- Vincula telefone a usuário e grupo com `entrar NOME GRUPO`
- Registra gastos por mensagem, por exemplo:
  - `gastei 50 almoço`
  - `35 uber`
  - `mercado 120,50`
  - `R$ 1.200,50 supermercado`
- Detecta categoria automaticamente
- Salva sessão em `bot_sessions/{phone}`
- Salva gasto em `grupos/{group}/usuarios/{user}/gastos/{ano_mes}/{id}`
- Mostra `resumo` do mês por categoria

## Segurança importante

Nunca envie o arquivo `.env` para o GitHub.

Use o arquivo `.env.example` como modelo e configure as variáveis reais no Railway em **Variables**. Se os tokens já foram enviados em conversa, repositório público ou ZIP compartilhado, gere novos tokens no painel da Z-API/Firebase quando possível.

## Variáveis de ambiente

Copie `.env.example` para `.env` apenas no seu computador local:

```bash
cp .env.example .env
```

No Railway, cadastre as variáveis manualmente.

A Z-API normalmente exige o header `Client-Token` no envio de mensagens. Por isso, preencha também:

```env
ZAPI_CLIENT_TOKEN=seu_client_token
```

## Deploy no Railway

1. Crie um repositório no GitHub com estes arquivos, sem `.env`.
2. No Railway: **New Project → Deploy from GitHub Repo**.
3. Em **Variables**, adicione os valores do `.env.example` preenchidos.
4. Confira se o deploy iniciou com `npm start`.
5. Abra a URL gerada pelo Railway e verifique se retorna:

```json
{ "status": "ok", "bot": "SalvaMoney", "version": "1.1.0" }
```

## Webhook na Z-API

Configure o webhook de mensagens recebidas apontando para:

```text
https://SUA-URL.railway.app/webhook
```

A URL precisa ser HTTPS.

## Comandos

| Mensagem | O que faz |
|---|---|
| `entrar João CASA2024` | Vincula o telefone ao usuário/grupo |
| `entrar Carlos Daniel CASA2024` | Também funciona com nome composto |
| `gastei 50 almoço` | Registra R$50 em Alimentação |
| `35 uber` | Registra R$35 em Transporte |
| `mercado 120,50` | Registra R$120,50 em Alimentação |
| `resumo` | Mostra total do mês por categoria |
| `ajuda` | Mostra os comandos |

## Formato no Firebase

```text
bot_sessions/
  {phone}/
    user: "João"
    group: "CASA2024"
    updatedAt: "2026-05-14"

grupos/{group}/usuarios/{user}/gastos/{ano_mes}/
  {id}/
    desc: "almoço"
    value: 50
    cat: "Alimentação"
    date: "2026-05-14"
    user: "João"
    viaBot: true
    createdAt: "2026-05-14T...Z"
```

## Compatibilidade do mês

Por padrão, o bot usa `MONTH_INDEX_MODE=zero`, ou seja, Maio vira `2026_4`, igual ao `getMonth()` do JavaScript.

Se o site estiver usando mês humano, como Maio = `2026_5`, mude para:

```env
MONTH_INDEX_MODE=one
```
